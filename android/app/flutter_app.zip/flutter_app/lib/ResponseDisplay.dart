import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'AppState.dart';

class ResponseDisplay extends StatefulWidget {
  @override
  _ResponseDisplayState createState() => _ResponseDisplayState();
}

class _ResponseDisplayState extends State<ResponseDisplay> {
  var isSelected = false;

  var _listKey;

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);

    return Container(
      padding: const EdgeInsets.all(16.0),
      child: appState.isFetching
          ? Center(child: CircularProgressIndicator())
          : appState.getResponseJson() != null
              ? ListView.builder(
                  primary: false,
                  shrinkWrap: true,
                  itemCount: appState.getResponseJson().length,
                  itemBuilder: (context, index) {
                    return Card(
                      child: ListTile(
                        key: _listKey,

//            leading: CircleAvatar(
//              backgroundImage: NetworkImage(
//                  appState.getResponseJson()[index]['avatar']),
//            ),
                        selected: isSelected,
                        title: Text(
                          appState.getResponseJson()[index]["name"],
                        ),
                        subtitle: Text(appState
                            .getResponseJson()[index]["selected"]
                            .toString()),
                        trailing: appState.getResponseJson()[index]["selected"]
                            ? Icon(Icons.check_circle)
                            : Container(
                                height: 0,
                                width: 0,
                              ),
                        onLongPress: () {
                          toggleSelection(index, appState);
                        },
                      ),
                    );
                  },
                )
              : Text("Press Button above to fetch data"),
    );
  }

  void toggleSelection(int index, final appState) {
    if (appState.getResponseJson()[index]["selected"]) {
      appState.getResponseJson()[index]["selected"] = false;
    } else {
      appState.getResponseJson()[index]["selected"] = true;
    }

    appState.toggleAppbarButtons();
    appState.notifyListeners();
  }
}

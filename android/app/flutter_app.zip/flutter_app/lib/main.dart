import 'package:flutter/material.dart';
import 'package:flutter_app/ResponseDisplay.dart';

import 'package:provider/provider.dart';

import 'AppState.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: ChangeNotifierProvider<AppState>(
          builder: (_) => AppState(),
          child: MyHomePage(),
        ));
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: Provider.of<AppState>(context).toggleAppbarButtons()? <Widget>[
          IconButton(
              onPressed: () {
                Provider.of<AppState>(context).deleteSelected();
              },
              icon: Icon(
                Icons.delete,
              )),
          IconButton(
              onPressed: () {
                Provider.of<AppState>(context).unselectAll();
              },
              icon: Icon(
                Icons.clear,
              ))
        ]:<Widget>[]),

      floatingActionButton: FloatingActionButton(
        child: IconButton(
          icon: Icon(
            Icons.refresh,
            color: Colors.white,
          ),
        ),
        onPressed: () => Provider.of<AppState>(context).fetchData(),
      ),
      body: ResponseDisplay(),
    );
  }
}
